<?php

get_template_part( 'template-parts/partials/sections/hero' );
get_template_part( 'template-parts/partials/sections/card-carousel' );
get_template_part( 'template-parts/partials/sections/support-section' );
get_template_part( 'template-parts/partials/sections/profit-section' );
get_template_part( 'template-parts/partials/sections/recommendation-carousel' );
get_template_part( 'template-parts/partials/sections/instagram' );
