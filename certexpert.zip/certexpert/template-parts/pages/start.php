<?php

get_template_part( 'template-parts/partials/sections/banner' );
get_template_part( 'template-parts/partials/sections/start-sections' );
