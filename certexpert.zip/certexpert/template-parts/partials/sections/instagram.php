<?php
?>

<section  data-aos-delay="100"  data-aos="fade-up" class="recommendations-  my-4 relative pb-8" >
	<div class="container mx-auto p-12  lg:px-24 2xl:px-16  ">
		<h2 class="font-barlow text-3xl lg:text-4xl font-bold text-black mb-8 relative">Instagram</h2>
<?php echo do_shortcode('')?>
	</div>
</section>
