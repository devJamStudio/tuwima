jQuery(document).ready(function($) {
	// Your jQuery code here
	console.log("jQuery is working!");
	jQuery("#map-poland").CSSMap({
		"size": 960
	});
	console.log( "ready!" );
});
